<template>
  <div class="activity">
    社区
  </div>
</template>
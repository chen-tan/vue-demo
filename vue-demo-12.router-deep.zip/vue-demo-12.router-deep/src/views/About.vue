<template>
  <div class="about">
    关于
  </div>
</template>
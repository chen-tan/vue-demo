<template>
  <div class="student">
    学员展示
  </div>
</template>
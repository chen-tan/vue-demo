export default {
    render(h){
        return h('div','router-view');
    }
}
<template>
    <div>资源下载</div>
</template>
<script>
export default {
    
}
</script>
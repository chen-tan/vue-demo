<template>
    <div>
        撒旦发射点 
    </div>
</template>
<script>
export default {
    
}
</script>
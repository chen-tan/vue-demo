<template>
    <div>学术讨论</div>
</template>
<script>
export default {
    
}
</script>
<template>
    <div class="home">
        <div>首页</div>
        <!-- <div class="test">测试</div> -->
    </div>
    
</template>
<script>
export default {
    
}
</script>
<style scoped>
    .home{
        position:relative;
    }
    .test{
        position:absolute;
        top:1000px;
        background-color:red;
    }
</style>